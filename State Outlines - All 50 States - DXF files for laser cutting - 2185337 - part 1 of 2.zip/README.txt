State Outlines - All 50 States - DXF files for laser cutting by oncemoore on Thingiverse: https://www.thingiverse.com/thing:2185337

Summary:
Outlines of each of the 50 united states in dxf format.(If you feel moved to tip me for my work, you are awesome. And if not, you're still awesome. Enjoy!)